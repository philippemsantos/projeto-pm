from flask_sqlalchemy import SQLAlchemy
from src.models.user import db
from datetime import datetime

class RegistroDiario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    data = db.Column(db.Date, nullable=False, default=datetime.utcnow)
    coordenador = db.Column(db.String(100), nullable=False)
    unidade = db.Column(db.String(100), nullable=False)
    qtu = db.Column(db.String(20), nullable=False)
    
    # Campos para faltas
    faltas_externas = db.Column(db.Text)  # JSON string
    faltas_internas = db.Column(db.Text)  # JSON string
    
    # Campos para atrasos
    atrasos = db.Column(db.Text)  # JSON string
    
    # Campos para permutas
    permutas = db.Column(db.Text)  # JSON string
    
    # Campos para dispensas
    dispensas = db.Column(db.Text)  # JSON string
    
    # Campos para remanejamento
    remanejamento = db.Column(db.Text)  # JSON string
    
    # Campos para banco de horas
    banco_horas = db.Column(db.Text)  # JSON string
    
    # Campos para equipes de serviço
    viaturas_area = db.Column(db.Text)  # JSON string
    policiamento_moto = db.Column(db.Text)  # JSON string
    policiamento_base = db.Column(db.Text)  # JSON string
    policiamento_quadriciclo = db.Column(db.Text)  # JSON string
    policiamento_ostensivo = db.Column(db.Text)  # JSON string
    
    # Campos para alterações
    alteracoes = db.Column(db.Text)
    
    # Campos para documentos
    documentos = db.Column(db.Text)
    
    # Campos para ocorrências
    ocorrencias = db.Column(db.Text)
    
    # Outros
    outros = db.Column(db.Text)
    
    # Passagem de serviço
    passagem_servico = db.Column(db.Text)
    
    def __repr__(self):
        return f'<RegistroDiario {self.data} - {self.coordenador}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'data': self.data.isoformat() if self.data else None,
            'coordenador': self.coordenador,
            'unidade': self.unidade,
            'qtu': self.qtu,
            'faltas_externas': self.faltas_externas,
            'faltas_internas': self.faltas_internas,
            'atrasos': self.atrasos,
            'permutas': self.permutas,
            'dispensas': self.dispensas,
            'remanejamento': self.remanejamento,
            'banco_horas': self.banco_horas,
            'viaturas_area': self.viaturas_area,
            'policiamento_moto': self.policiamento_moto,
            'policiamento_base': self.policiamento_base,
            'policiamento_quadriciclo': self.policiamento_quadriciclo,
            'policiamento_ostensivo': self.policiamento_ostensivo,
            'alteracoes': self.alteracoes,
            'documentos': self.documentos,
            'ocorrencias': self.ocorrencias,
            'outros': self.outros,
            'passagem_servico': self.passagem_servico
        }

