from flask_sqlalchemy import SQLAlchemy
from src.models.user import db

class Policial(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    matricula = db.Column(db.String(20), unique=True, nullable=False)
    unidade = db.Column(db.String(100), nullable=False)
    cargo = db.Column(db.String(50), nullable=False)
    
    def __repr__(self):
        return f'<Policial {self.nome} - {self.matricula}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'nome': self.nome,
            'matricula': self.matricula,
            'unidade': self.unidade,
            'cargo': self.cargo
        }

