from flask import Blueprint, request, jsonify
from src.models.user import db
from src.models.registro_diario import RegistroDiario
from datetime import datetime
import json

registro_bp = Blueprint('registro', __name__)

@registro_bp.route('/registros', methods=['GET'])
def get_registros():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        
        registros = RegistroDiario.query.paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'registros': [registro.to_dict() for registro in registros.items],
            'total': registros.total,
            'pages': registros.pages,
            'current_page': page
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@registro_bp.route('/registros', methods=['POST'])
def create_registro():
    try:
        data = request.get_json()
        
        if not data or not all(k in data for k in ('coordenador', 'unidade', 'qtu')):
            return jsonify({'error': 'Dados incompletos'}), 400
        
        # Converter data se fornecida
        data_registro = datetime.utcnow().date()
        if 'data' in data and data['data']:
            try:
                data_registro = datetime.fromisoformat(data['data']).date()
            except ValueError:
                return jsonify({'error': 'Formato de data inválido'}), 400
        
        registro = RegistroDiario(
            data=data_registro,
            coordenador=data['coordenador'],
            unidade=data['unidade'],
            qtu=data['qtu'],
            faltas_externas=json.dumps(data.get('faltas_externas', [])),
            faltas_internas=json.dumps(data.get('faltas_internas', [])),
            atrasos=json.dumps(data.get('atrasos', [])),
            permutas=json.dumps(data.get('permutas', [])),
            dispensas=json.dumps(data.get('dispensas', [])),
            remanejamento=json.dumps(data.get('remanejamento', [])),
            banco_horas=json.dumps(data.get('banco_horas', [])),
            viaturas_area=json.dumps(data.get('viaturas_area', [])),
            policiamento_moto=json.dumps(data.get('policiamento_moto', [])),
            policiamento_base=json.dumps(data.get('policiamento_base', [])),
            policiamento_quadriciclo=json.dumps(data.get('policiamento_quadriciclo', [])),
            policiamento_ostensivo=json.dumps(data.get('policiamento_ostensivo', [])),
            alteracoes=data.get('alteracoes', ''),
            documentos=data.get('documentos', ''),
            ocorrencias=data.get('ocorrencias', ''),
            outros=data.get('outros', ''),
            passagem_servico=data.get('passagem_servico', '')
        )
        
        db.session.add(registro)
        db.session.commit()
        
        return jsonify(registro.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@registro_bp.route('/registros/<int:registro_id>', methods=['GET'])
def get_registro(registro_id):
    try:
        registro = RegistroDiario.query.get_or_404(registro_id)
        return jsonify(registro.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@registro_bp.route('/registros/<int:registro_id>', methods=['PUT'])
def update_registro(registro_id):
    try:
        registro = RegistroDiario.query.get_or_404(registro_id)
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'Dados não fornecidos'}), 400
        
        # Atualizar campos básicos
        if 'coordenador' in data:
            registro.coordenador = data['coordenador']
        if 'unidade' in data:
            registro.unidade = data['unidade']
        if 'qtu' in data:
            registro.qtu = data['qtu']
        if 'data' in data and data['data']:
            try:
                registro.data = datetime.fromisoformat(data['data']).date()
            except ValueError:
                return jsonify({'error': 'Formato de data inválido'}), 400
        
        # Atualizar campos JSON
        json_fields = [
            'faltas_externas', 'faltas_internas', 'atrasos', 'permutas',
            'dispensas', 'remanejamento', 'banco_horas', 'viaturas_area',
            'policiamento_moto', 'policiamento_base', 'policiamento_quadriciclo',
            'policiamento_ostensivo'
        ]
        
        for field in json_fields:
            if field in data:
                setattr(registro, field, json.dumps(data[field]))
        
        # Atualizar campos de texto
        text_fields = ['alteracoes', 'documentos', 'ocorrencias', 'outros', 'passagem_servico']
        for field in text_fields:
            if field in data:
                setattr(registro, field, data[field])
        
        db.session.commit()
        
        return jsonify(registro.to_dict())
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@registro_bp.route('/registros/<int:registro_id>', methods=['DELETE'])
def delete_registro(registro_id):
    try:
        registro = RegistroDiario.query.get_or_404(registro_id)
        db.session.delete(registro)
        db.session.commit()
        
        return jsonify({'message': 'Registro removido com sucesso'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@registro_bp.route('/registros/por-data', methods=['GET'])
def get_registros_por_data():
    try:
        data_inicio = request.args.get('data_inicio')
        data_fim = request.args.get('data_fim')
        
        query = RegistroDiario.query
        
        if data_inicio:
            try:
                data_inicio_obj = datetime.fromisoformat(data_inicio).date()
                query = query.filter(RegistroDiario.data >= data_inicio_obj)
            except ValueError:
                return jsonify({'error': 'Formato de data_inicio inválido'}), 400
        
        if data_fim:
            try:
                data_fim_obj = datetime.fromisoformat(data_fim).date()
                query = query.filter(RegistroDiario.data <= data_fim_obj)
            except ValueError:
                return jsonify({'error': 'Formato de data_fim inválido'}), 400
        
        registros = query.order_by(RegistroDiario.data.desc()).all()
        
        return jsonify([registro.to_dict() for registro in registros])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

