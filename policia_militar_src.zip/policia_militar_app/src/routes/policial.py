from flask import Blueprint, request, jsonify
from src.models.user import db
from src.models.policial import Policial

policial_bp = Blueprint('policial', __name__)

@policial_bp.route('/policiais', methods=['GET'])
def get_policiais():
    try:
        policiais = Policial.query.all()
        return jsonify([policial.to_dict() for policial in policiais])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@policial_bp.route('/policiais', methods=['POST'])
def create_policial():
    try:
        data = request.get_json()
        
        if not data or not all(k in data for k in ('nome', 'matricula', 'unidade', 'cargo')):
            return jsonify({'error': 'Dados incompletos'}), 400
        
        # Verificar se a matrícula já existe
        existing = Policial.query.filter_by(matricula=data['matricula']).first()
        if existing:
            return jsonify({'error': 'Matrícula já existe'}), 400
        
        policial = Policial(
            nome=data['nome'],
            matricula=data['matricula'],
            unidade=data['unidade'],
            cargo=data['cargo']
        )
        
        db.session.add(policial)
        db.session.commit()
        
        return jsonify(policial.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@policial_bp.route('/policiais/<int:policial_id>', methods=['GET'])
def get_policial(policial_id):
    try:
        policial = Policial.query.get_or_404(policial_id)
        return jsonify(policial.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@policial_bp.route('/policiais/<int:policial_id>', methods=['PUT'])
def update_policial(policial_id):
    try:
        policial = Policial.query.get_or_404(policial_id)
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'Dados não fornecidos'}), 400
        
        # Verificar se a nova matrícula já existe (se foi alterada)
        if 'matricula' in data and data['matricula'] != policial.matricula:
            existing = Policial.query.filter_by(matricula=data['matricula']).first()
            if existing:
                return jsonify({'error': 'Matrícula já existe'}), 400
        
        # Atualizar campos
        if 'nome' in data:
            policial.nome = data['nome']
        if 'matricula' in data:
            policial.matricula = data['matricula']
        if 'unidade' in data:
            policial.unidade = data['unidade']
        if 'cargo' in data:
            policial.cargo = data['cargo']
        
        db.session.commit()
        
        return jsonify(policial.to_dict())
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@policial_bp.route('/policiais/<int:policial_id>', methods=['DELETE'])
def delete_policial(policial_id):
    try:
        policial = Policial.query.get_or_404(policial_id)
        db.session.delete(policial)
        db.session.commit()
        
        return jsonify({'message': 'Policial removido com sucesso'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@policial_bp.route('/policiais/search', methods=['GET'])
def search_policiais():
    try:
        query = request.args.get('q', '')
        if not query:
            return jsonify([])
        
        policiais = Policial.query.filter(
            (Policial.nome.contains(query)) |
            (Policial.matricula.contains(query)) |
            (Policial.unidade.contains(query)) |
            (Policial.cargo.contains(query))
        ).all()
        
        return jsonify([policial.to_dict() for policial in policiais])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

