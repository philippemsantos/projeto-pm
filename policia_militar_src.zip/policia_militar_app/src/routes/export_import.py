from flask import Blueprint, request, jsonify, send_file
from src.models.user import db
from src.models.registro_diario import RegistroDiario
from src.models.policial import Policial
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from docx import Document
from docx.shared import Inches
import json
import os
import tempfile
from datetime import datetime

export_import_bp = Blueprint('export_import', __name__)

def create_pdf_report(registros):
    """Cria um relatório PDF com os registros diários"""
    # Criar arquivo temporário
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.pdf')
    
    # Configurar documento
    doc = SimpleDocTemplate(temp_file.name, pagesize=A4)
    styles = getSampleStyleSheet()
    
    # Estilo personalizado para título
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=16,
        spaceAfter=30,
        alignment=1  # Centralizado
    )
    
    # Conteúdo do documento
    story = []
    
    # Título
    title = Paragraph("RELATÓRIO DE REGISTROS DIÁRIOS<br/>POLÍCIA MILITAR DO MARANHÃO", title_style)
    story.append(title)
    story.append(Spacer(1, 20))
    
    for registro in registros:
        # Cabeçalho do registro
        data_formatada = datetime.fromisoformat(registro.data).strftime('%d/%m/%Y') if registro.data else 'N/A'
        
        header_data = [
            ['Data:', data_formatada, 'QTU:', registro.qtu or 'N/A'],
            ['Coordenador:', registro.coordenador or 'N/A', 'Unidade:', registro.unidade or 'N/A']
        ]
        
        header_table = Table(header_data, colWidths=[1*inch, 2*inch, 1*inch, 2*inch])
        header_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        story.append(header_table)
        story.append(Spacer(1, 12))
        
        # Seções do registro
        sections = [
            ('FALTAS EXTERNAS', registro.faltas_externas),
            ('FALTAS INTERNAS', registro.faltas_internas),
            ('ATRASOS', registro.atrasos),
            ('PERMUTAS', registro.permutas),
            ('VIATURAS DE ÁREA', registro.viaturas_area),
            ('POLICIAMENTO MOTOCICLETA', registro.policiamento_moto),
            ('POLICIAMENTO BASE', registro.policiamento_base),
            ('ALTERAÇÕES', registro.alteracoes),
            ('OCORRÊNCIAS', registro.ocorrencias),
            ('PASSAGEM DE SERVIÇO', registro.passagem_servico)
        ]
        
        for section_title, section_content in sections:
            if section_content and section_content.strip():
                story.append(Paragraph(f"<b>{section_title}:</b>", styles['Heading3']))
                story.append(Paragraph(section_content, styles['Normal']))
                story.append(Spacer(1, 12))
        
        story.append(Spacer(1, 20))
    
    # Gerar PDF
    doc.build(story)
    temp_file.close()
    
    return temp_file.name

def create_docx_report(registros):
    """Cria um relatório DOCX com os registros diários"""
    # Criar documento
    doc = Document()
    
    # Título
    title = doc.add_heading('RELATÓRIO DE REGISTROS DIÁRIOS', 0)
    title.alignment = 1  # Centralizado
    
    subtitle = doc.add_heading('POLÍCIA MILITAR DO MARANHÃO', level=1)
    subtitle.alignment = 1
    
    for registro in registros:
        # Quebra de página entre registros (exceto o primeiro)
        if registros.index(registro) > 0:
            doc.add_page_break()
        
        # Cabeçalho do registro
        data_formatada = datetime.fromisoformat(registro.data).strftime('%d/%m/%Y') if registro.data else 'N/A'
        
        table = doc.add_table(rows=2, cols=4)
        table.style = 'Table Grid'
        
        # Primeira linha
        cells = table.rows[0].cells
        cells[0].text = 'Data:'
        cells[1].text = data_formatada
        cells[2].text = 'QTU:'
        cells[3].text = registro.qtu or 'N/A'
        
        # Segunda linha
        cells = table.rows[1].cells
        cells[0].text = 'Coordenador:'
        cells[1].text = registro.coordenador or 'N/A'
        cells[2].text = 'Unidade:'
        cells[3].text = registro.unidade or 'N/A'
        
        doc.add_paragraph()
        
        # Seções do registro
        sections = [
            ('FALTAS EXTERNAS', registro.faltas_externas),
            ('FALTAS INTERNAS', registro.faltas_internas),
            ('ATRASOS', registro.atrasos),
            ('PERMUTAS', registro.permutas),
            ('VIATURAS DE ÁREA', registro.viaturas_area),
            ('POLICIAMENTO MOTOCICLETA', registro.policiamento_moto),
            ('POLICIAMENTO BASE', registro.policiamento_base),
            ('ALTERAÇÕES', registro.alteracoes),
            ('OCORRÊNCIAS', registro.ocorrencias),
            ('PASSAGEM DE SERVIÇO', registro.passagem_servico)
        ]
        
        for section_title, section_content in sections:
            if section_content and section_content.strip():
                doc.add_heading(section_title, level=2)
                doc.add_paragraph(section_content)
    
    # Salvar em arquivo temporário
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.docx')
    doc.save(temp_file.name)
    temp_file.close()
    
    return temp_file.name

@export_import_bp.route('/export/pdf', methods=['GET'])
def export_pdf():
    try:
        # Buscar todos os registros
        registros = RegistroDiario.query.order_by(RegistroDiario.data.desc()).all()
        
        if not registros:
            return jsonify({'error': 'Nenhum registro encontrado para exportar'}), 404
        
        # Criar PDF
        pdf_path = create_pdf_report(registros)
        
        # Enviar arquivo
        return send_file(
            pdf_path,
            as_attachment=True,
            download_name=f'registros_diarios_{datetime.now().strftime("%Y%m%d")}.pdf',
            mimetype='application/pdf'
        )
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    
    finally:
        # Limpar arquivo temporário
        if 'pdf_path' in locals() and os.path.exists(pdf_path):
            os.unlink(pdf_path)

@export_import_bp.route('/export/docx', methods=['GET'])
def export_docx():
    try:
        # Buscar todos os registros
        registros = RegistroDiario.query.order_by(RegistroDiario.data.desc()).all()
        
        if not registros:
            return jsonify({'error': 'Nenhum registro encontrado para exportar'}), 404
        
        # Criar DOCX
        docx_path = create_docx_report(registros)
        
        # Enviar arquivo
        return send_file(
            docx_path,
            as_attachment=True,
            download_name=f'registros_diarios_{datetime.now().strftime("%Y%m%d")}.docx',
            mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        )
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    
    finally:
        # Limpar arquivo temporário
        if 'docx_path' in locals() and os.path.exists(docx_path):
            os.unlink(docx_path)

@export_import_bp.route('/import', methods=['POST'])
def import_file():
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'Nenhum arquivo enviado'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'Nenhum arquivo selecionado'}), 400
        
        # Verificar tipo de arquivo
        if not file.filename.lower().endswith(('.pdf', '.docx')):
            return jsonify({'error': 'Apenas arquivos PDF e DOCX são aceitos'}), 400
        
        # Por enquanto, retornar mensagem de funcionalidade em desenvolvimento
        return jsonify({
            'message': 'Funcionalidade de importação em desenvolvimento',
            'filename': file.filename,
            'size': len(file.read())
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

