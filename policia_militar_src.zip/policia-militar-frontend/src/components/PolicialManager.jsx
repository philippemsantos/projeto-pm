import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog.jsx'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx'
import { Plus, Search, Edit, Trash2, User } from 'lucide-react'

const API_BASE = '/api'

function PolicialManager() {
  const [policiais, setPoliciais] = useState([])
  const [searchTerm, setSearchTerm] = useState('')
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingPolicial, setEditingPolicial] = useState(null)
  const [formData, setFormData] = useState({
    nome: '',
    matricula: '',
    unidade: '',
    cargo: ''
  })
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    fetchPoliciais()
  }, [])

  const fetchPoliciais = async () => {
    try {
      setLoading(true)
      const response = await fetch(`${API_BASE}/policiais`)
      if (response.ok) {
        const data = await response.json()
        setPoliciais(data)
      }
    } catch (error) {
      console.error('Erro ao buscar policiais:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      setLoading(true)
      const url = editingPolicial 
        ? `${API_BASE}/policiais/${editingPolicial.id}`
        : `${API_BASE}/policiais`
      
      const method = editingPolicial ? 'PUT' : 'POST'
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        await fetchPoliciais()
        setIsDialogOpen(false)
        setEditingPolicial(null)
        setFormData({ nome: '', matricula: '', unidade: '', cargo: '' })
      } else {
        const error = await response.json()
        alert(error.error || 'Erro ao salvar policial')
      }
    } catch (error) {
      console.error('Erro ao salvar policial:', error)
      alert('Erro ao salvar policial')
    } finally {
      setLoading(false)
    }
  }

  const handleEdit = (policial) => {
    setEditingPolicial(policial)
    setFormData({
      nome: policial.nome,
      matricula: policial.matricula,
      unidade: policial.unidade,
      cargo: policial.cargo
    })
    setIsDialogOpen(true)
  }

  const handleDelete = async (id) => {
    if (!confirm('Tem certeza que deseja excluir este policial?')) return
    
    try {
      setLoading(true)
      const response = await fetch(`${API_BASE}/policiais/${id}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        await fetchPoliciais()
      } else {
        alert('Erro ao excluir policial')
      }
    } catch (error) {
      console.error('Erro ao excluir policial:', error)
      alert('Erro ao excluir policial')
    } finally {
      setLoading(false)
    }
  }

  const filteredPoliciais = policiais.filter(policial =>
    policial.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    policial.matricula.toLowerCase().includes(searchTerm.toLowerCase()) ||
    policial.unidade.toLowerCase().includes(searchTerm.toLowerCase()) ||
    policial.cargo.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const openNewDialog = () => {
    setEditingPolicial(null)
    setFormData({ nome: '', matricula: '', unidade: '', cargo: '' })
    setIsDialogOpen(true)
  }

  return (
    <div className="container mx-auto p-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-blue-900 mb-2">Gestão de Policiais</h1>
          <p className="text-gray-600">Cadastre e gerencie os policiais militares</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={openNewDialog} className="mt-4 md:mt-0">
              <Plus className="mr-2 h-4 w-4" />
              Novo Policial
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>
                {editingPolicial ? 'Editar Policial' : 'Novo Policial'}
              </DialogTitle>
              <DialogDescription>
                {editingPolicial 
                  ? 'Edite as informações do policial militar'
                  : 'Cadastre um novo policial militar no sistema'
                }
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="nome">Nome Completo</Label>
                <Input
                  id="nome"
                  value={formData.nome}
                  onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="matricula">Matrícula</Label>
                <Input
                  id="matricula"
                  value={formData.matricula}
                  onChange={(e) => setFormData({ ...formData, matricula: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="unidade">Unidade</Label>
                <Input
                  id="unidade"
                  value={formData.unidade}
                  onChange={(e) => setFormData({ ...formData, unidade: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="cargo">Cargo/Graduação</Label>
                <Input
                  id="cargo"
                  value={formData.cargo}
                  onChange={(e) => setFormData({ ...formData, cargo: e.target.value })}
                  required
                />
              </div>
              <div className="flex justify-end space-x-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsDialogOpen(false)}
                >
                  Cancelar
                </Button>
                <Button type="submit" disabled={loading}>
                  {loading ? 'Salvando...' : 'Salvar'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <CardTitle className="flex items-center space-x-2">
                <User className="text-blue-600" />
                <span>Policiais Cadastrados</span>
              </CardTitle>
              <CardDescription>
                Total: {policiais.length} policiais
              </CardDescription>
            </div>
            <div className="mt-4 md:mt-0 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Buscar por nome, matrícula, unidade..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full md:w-80"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">Carregando...</div>
          ) : filteredPoliciais.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              {searchTerm ? 'Nenhum policial encontrado' : 'Nenhum policial cadastrado'}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Matrícula</TableHead>
                    <TableHead>Unidade</TableHead>
                    <TableHead>Cargo</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPoliciais.map((policial) => (
                    <TableRow key={policial.id}>
                      <TableCell className="font-medium">{policial.nome}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{policial.matricula}</Badge>
                      </TableCell>
                      <TableCell>{policial.unidade}</TableCell>
                      <TableCell>{policial.cargo}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEdit(policial)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDelete(policial.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default PolicialManager

