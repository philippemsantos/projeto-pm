import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Download, Upload, FileText, File } from 'lucide-react'

const API_BASE = '/api'

function ExportImport() {
  const [loading, setLoading] = useState(false)
  const [selectedFile, setSelectedFile] = useState(null)

  const handleExportPDF = async () => {
    try {
      setLoading(true)
      const response = await fetch(`${API_BASE}/export/pdf`)
      
      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.style.display = 'none'
        a.href = url
        a.download = `registros_diarios_${new Date().toISOString().split('T')[0]}.pdf`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
      } else {
        const error = await response.json()
        alert(error.error || 'Erro ao exportar PDF')
      }
    } catch (error) {
      console.error('Erro ao exportar PDF:', error)
      alert('Erro ao exportar PDF')
    } finally {
      setLoading(false)
    }
  }

  const handleExportDOCX = async () => {
    try {
      setLoading(true)
      const response = await fetch(`${API_BASE}/export/docx`)
      
      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.style.display = 'none'
        a.href = url
        a.download = `registros_diarios_${new Date().toISOString().split('T')[0]}.docx`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
      } else {
        const error = await response.json()
        alert(error.error || 'Erro ao exportar DOCX')
      }
    } catch (error) {
      console.error('Erro ao exportar DOCX:', error)
      alert('Erro ao exportar DOCX')
    } finally {
      setLoading(false)
    }
  }

  const handleImport = async () => {
    if (!selectedFile) {
      alert('Selecione um arquivo para importar')
      return
    }

    try {
      setLoading(true)
      const formData = new FormData()
      formData.append('file', selectedFile)
      
      const response = await fetch(`${API_BASE}/import`, {
        method: 'POST',
        body: formData
      })
      
      if (response.ok) {
        const result = await response.json()
        alert(result.message || 'Arquivo importado com sucesso')
        setSelectedFile(null)
        document.getElementById('file-upload').value = ''
      } else {
        const error = await response.json()
        alert(error.error || 'Erro ao importar arquivo')
      }
    } catch (error) {
      console.error('Erro ao importar arquivo:', error)
      alert('Erro ao importar arquivo')
    } finally {
      setLoading(false)
    }
  }

  const handleFileChange = (e) => {
    const file = e.target.files[0]
    if (file) {
      const validTypes = ['application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document']
      if (validTypes.includes(file.type)) {
        setSelectedFile(file)
      } else {
        alert('Apenas arquivos PDF e DOCX são aceitos')
        e.target.value = ''
      }
    }
  }

  return (
    <div className="container mx-auto p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-blue-900 mb-2">Exportar/Importar</h1>
        <p className="text-gray-600">Exporte dados para PDF/DOCX ou importe dados existentes</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Exportação */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Download className="text-green-600" />
              <span>Exportar Dados</span>
            </CardTitle>
            <CardDescription>
              Exporte os registros diários para arquivos PDF ou DOCX
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <Button 
                onClick={handleExportPDF} 
                disabled={loading}
                className="w-full justify-start"
                variant="outline"
              >
                <FileText className="mr-2 h-4 w-4 text-red-600" />
                Exportar como PDF
              </Button>
              
              <Button 
                onClick={handleExportDOCX} 
                disabled={loading}
                className="w-full justify-start"
                variant="outline"
              >
                <File className="mr-2 h-4 w-4 text-blue-600" />
                Exportar como DOCX
              </Button>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-semibold text-blue-900 mb-2">Formatos de Exportação</h4>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• <strong>PDF:</strong> Formato oficial para impressão e arquivo</li>
                <li>• <strong>DOCX:</strong> Formato editável para Microsoft Word</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Importação */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Upload className="text-purple-600" />
              <span>Importar Dados</span>
            </CardTitle>
            <CardDescription>
              Importe dados de arquivos PDF ou DOCX existentes
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="file-upload">Selecionar Arquivo</Label>
              <Input
                id="file-upload"
                type="file"
                accept=".pdf,.docx"
                onChange={handleFileChange}
                className="mt-1"
              />
              {selectedFile && (
                <div className="mt-2">
                  <Badge variant="outline" className="flex items-center space-x-1 w-fit">
                    <File className="h-3 w-3" />
                    <span>{selectedFile.name}</span>
                  </Badge>
                </div>
              )}
            </div>

            <Button 
              onClick={handleImport} 
              disabled={loading || !selectedFile}
              className="w-full"
            >
              {loading ? 'Importando...' : 'Importar Arquivo'}
            </Button>

            <div className="bg-purple-50 p-4 rounded-lg">
              <h4 className="font-semibold text-purple-900 mb-2">Formatos Suportados</h4>
              <ul className="text-sm text-purple-800 space-y-1">
                <li>• <strong>PDF:</strong> Extração automática de dados estruturados</li>
                <li>• <strong>DOCX:</strong> Importação de documentos do Word</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Instruções */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Instruções de Uso</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">Exportação</h4>
              <ol className="text-sm text-gray-600 space-y-1 list-decimal list-inside">
                <li>Certifique-se de que há registros cadastrados no sistema</li>
                <li>Escolha o formato desejado (PDF ou DOCX)</li>
                <li>Clique no botão de exportação correspondente</li>
                <li>O arquivo será baixado automaticamente</li>
              </ol>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">Importação</h4>
              <ol className="text-sm text-gray-600 space-y-1 list-decimal list-inside">
                <li>Prepare o arquivo PDF ou DOCX com os dados</li>
                <li>Clique em "Selecionar Arquivo" e escolha o arquivo</li>
                <li>Verifique se o arquivo foi selecionado corretamente</li>
                <li>Clique em "Importar Arquivo" para processar</li>
              </ol>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default ExportImport

