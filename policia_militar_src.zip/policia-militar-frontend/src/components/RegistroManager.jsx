import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog.jsx'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Plus, Search, Edit, Trash2, FileText, Calendar } from 'lucide-react'

const API_BASE = '/api'

function RegistroManager() {
  const [registros, setRegistros] = useState([])
  const [searchTerm, setSearchTerm] = useState('')
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingRegistro, setEditingRegistro] = useState(null)
  const [formData, setFormData] = useState({
    data: new Date().toISOString().split('T')[0],
    coordenador: '',
    unidade: '',
    qtu: '',
    faltas_externas: '',
    faltas_internas: '',
    atrasos: '',
    permutas: '',
    dispensas: '',
    remanejamento: '',
    banco_horas: '',
    viaturas_area: '',
    policiamento_moto: '',
    policiamento_base: '',
    policiamento_quadriciclo: '',
    policiamento_ostensivo: '',
    alteracoes: '',
    documentos: '',
    ocorrencias: '',
    outros: '',
    passagem_servico: ''
  })
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    fetchRegistros()
  }, [])

  const fetchRegistros = async () => {
    try {
      setLoading(true)
      const response = await fetch(`${API_BASE}/registros`)
      if (response.ok) {
        const data = await response.json()
        setRegistros(data.registros || [])
      }
    } catch (error) {
      console.error('Erro ao buscar registros:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      setLoading(true)
      const url = editingRegistro 
        ? `${API_BASE}/registros/${editingRegistro.id}`
        : `${API_BASE}/registros`
      
      const method = editingRegistro ? 'PUT' : 'POST'
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        await fetchRegistros()
        setIsDialogOpen(false)
        setEditingRegistro(null)
        resetForm()
      } else {
        const error = await response.json()
        alert(error.error || 'Erro ao salvar registro')
      }
    } catch (error) {
      console.error('Erro ao salvar registro:', error)
      alert('Erro ao salvar registro')
    } finally {
      setLoading(false)
    }
  }

  const resetForm = () => {
    setFormData({
      data: new Date().toISOString().split('T')[0],
      coordenador: '',
      unidade: '',
      qtu: '',
      faltas_externas: '',
      faltas_internas: '',
      atrasos: '',
      permutas: '',
      dispensas: '',
      remanejamento: '',
      banco_horas: '',
      viaturas_area: '',
      policiamento_moto: '',
      policiamento_base: '',
      policiamento_quadriciclo: '',
      policiamento_ostensivo: '',
      alteracoes: '',
      documentos: '',
      ocorrencias: '',
      outros: '',
      passagem_servico: ''
    })
  }

  const handleEdit = (registro) => {
    setEditingRegistro(registro)
    setFormData({
      data: registro.data || new Date().toISOString().split('T')[0],
      coordenador: registro.coordenador || '',
      unidade: registro.unidade || '',
      qtu: registro.qtu || '',
      faltas_externas: registro.faltas_externas || '',
      faltas_internas: registro.faltas_internas || '',
      atrasos: registro.atrasos || '',
      permutas: registro.permutas || '',
      dispensas: registro.dispensas || '',
      remanejamento: registro.remanejamento || '',
      banco_horas: registro.banco_horas || '',
      viaturas_area: registro.viaturas_area || '',
      policiamento_moto: registro.policiamento_moto || '',
      policiamento_base: registro.policiamento_base || '',
      policiamento_quadriciclo: registro.policiamento_quadriciclo || '',
      policiamento_ostensivo: registro.policiamento_ostensivo || '',
      alteracoes: registro.alteracoes || '',
      documentos: registro.documentos || '',
      ocorrencias: registro.ocorrencias || '',
      outros: registro.outros || '',
      passagem_servico: registro.passagem_servico || ''
    })
    setIsDialogOpen(true)
  }

  const handleDelete = async (id) => {
    if (!confirm('Tem certeza que deseja excluir este registro?')) return
    
    try {
      setLoading(true)
      const response = await fetch(`${API_BASE}/registros/${id}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        await fetchRegistros()
      } else {
        alert('Erro ao excluir registro')
      }
    } catch (error) {
      console.error('Erro ao excluir registro:', error)
      alert('Erro ao excluir registro')
    } finally {
      setLoading(false)
    }
  }

  const filteredRegistros = registros.filter(registro =>
    registro.coordenador?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    registro.unidade?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    registro.qtu?.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const openNewDialog = () => {
    setEditingRegistro(null)
    resetForm()
    setIsDialogOpen(true)
  }

  return (
    <div className="container mx-auto p-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-blue-900 mb-2">Registros Diários</h1>
          <p className="text-gray-600">Gerencie os livros diários de policiamento</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={openNewDialog} className="mt-4 md:mt-0">
              <Plus className="mr-2 h-4 w-4" />
              Novo Registro
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[800px] max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingRegistro ? 'Editar Registro' : 'Novo Registro Diário'}
              </DialogTitle>
              <DialogDescription>
                {editingRegistro 
                  ? 'Edite as informações do registro diário'
                  : 'Crie um novo registro diário de policiamento'
                }
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <Tabs defaultValue="basico" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="basico">Básico</TabsTrigger>
                  <TabsTrigger value="pessoal">Pessoal</TabsTrigger>
                  <TabsTrigger value="equipes">Equipes</TabsTrigger>
                  <TabsTrigger value="outros">Outros</TabsTrigger>
                </TabsList>
                
                <TabsContent value="basico" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="data">Data</Label>
                      <Input
                        id="data"
                        type="date"
                        value={formData.data}
                        onChange={(e) => setFormData({ ...formData, data: e.target.value })}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="qtu">QTU</Label>
                      <Input
                        id="qtu"
                        value={formData.qtu}
                        onChange={(e) => setFormData({ ...formData, qtu: e.target.value })}
                        placeholder="Ex: 1º QTU"
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="coordenador">Coordenador</Label>
                    <Input
                      id="coordenador"
                      value={formData.coordenador}
                      onChange={(e) => setFormData({ ...formData, coordenador: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="unidade">Unidade</Label>
                    <Input
                      id="unidade"
                      value={formData.unidade}
                      onChange={(e) => setFormData({ ...formData, unidade: e.target.value })}
                      placeholder="Ex: 1º BPTUR"
                      required
                    />
                  </div>
                </TabsContent>

                <TabsContent value="pessoal" className="space-y-4">
                  <div>
                    <Label htmlFor="faltas_externas">Faltas Externas</Label>
                    <Textarea
                      id="faltas_externas"
                      value={formData.faltas_externas}
                      onChange={(e) => setFormData({ ...formData, faltas_externas: e.target.value })}
                      placeholder="Descreva as faltas de pessoal externo..."
                    />
                  </div>
                  <div>
                    <Label htmlFor="faltas_internas">Faltas Internas</Label>
                    <Textarea
                      id="faltas_internas"
                      value={formData.faltas_internas}
                      onChange={(e) => setFormData({ ...formData, faltas_internas: e.target.value })}
                      placeholder="Descreva as faltas de pessoal interno..."
                    />
                  </div>
                  <div>
                    <Label htmlFor="atrasos">Atrasos</Label>
                    <Textarea
                      id="atrasos"
                      value={formData.atrasos}
                      onChange={(e) => setFormData({ ...formData, atrasos: e.target.value })}
                      placeholder="Descreva os atrasos..."
                    />
                  </div>
                  <div>
                    <Label htmlFor="permutas">Permutas</Label>
                    <Textarea
                      id="permutas"
                      value={formData.permutas}
                      onChange={(e) => setFormData({ ...formData, permutas: e.target.value })}
                      placeholder="Descreva as permutas realizadas..."
                    />
                  </div>
                </TabsContent>

                <TabsContent value="equipes" className="space-y-4">
                  <div>
                    <Label htmlFor="viaturas_area">Viaturas de Área</Label>
                    <Textarea
                      id="viaturas_area"
                      value={formData.viaturas_area}
                      onChange={(e) => setFormData({ ...formData, viaturas_area: e.target.value })}
                      placeholder="Descreva as viaturas e suas áreas..."
                    />
                  </div>
                  <div>
                    <Label htmlFor="policiamento_moto">Policiamento Motocicleta</Label>
                    <Textarea
                      id="policiamento_moto"
                      value={formData.policiamento_moto}
                      onChange={(e) => setFormData({ ...formData, policiamento_moto: e.target.value })}
                      placeholder="Descreva o policiamento de motocicleta..."
                    />
                  </div>
                  <div>
                    <Label htmlFor="policiamento_base">Policiamento da Base</Label>
                    <Textarea
                      id="policiamento_base"
                      value={formData.policiamento_base}
                      onChange={(e) => setFormData({ ...formData, policiamento_base: e.target.value })}
                      placeholder="Descreva o policiamento das bases..."
                    />
                  </div>
                </TabsContent>

                <TabsContent value="outros" className="space-y-4">
                  <div>
                    <Label htmlFor="alteracoes">Alterações</Label>
                    <Textarea
                      id="alteracoes"
                      value={formData.alteracoes}
                      onChange={(e) => setFormData({ ...formData, alteracoes: e.target.value })}
                      placeholder="Descreva alterações em viaturas, equipamentos..."
                    />
                  </div>
                  <div>
                    <Label htmlFor="ocorrencias">Ocorrências</Label>
                    <Textarea
                      id="ocorrencias"
                      value={formData.ocorrencias}
                      onChange={(e) => setFormData({ ...formData, ocorrencias: e.target.value })}
                      placeholder="Descreva as ocorrências do dia..."
                    />
                  </div>
                  <div>
                    <Label htmlFor="passagem_servico">Passagem de Serviço</Label>
                    <Textarea
                      id="passagem_servico"
                      value={formData.passagem_servico}
                      onChange={(e) => setFormData({ ...formData, passagem_servico: e.target.value })}
                      placeholder="Descreva a passagem de serviço..."
                    />
                  </div>
                </TabsContent>
              </Tabs>

              <div className="flex justify-end space-x-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsDialogOpen(false)}
                >
                  Cancelar
                </Button>
                <Button type="submit" disabled={loading}>
                  {loading ? 'Salvando...' : 'Salvar'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <CardTitle className="flex items-center space-x-2">
                <FileText className="text-green-600" />
                <span>Registros Diários</span>
              </CardTitle>
              <CardDescription>
                Total: {registros.length} registros
              </CardDescription>
            </div>
            <div className="mt-4 md:mt-0 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Buscar por coordenador, unidade..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full md:w-80"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">Carregando...</div>
          ) : filteredRegistros.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              {searchTerm ? 'Nenhum registro encontrado' : 'Nenhum registro cadastrado'}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Data</TableHead>
                    <TableHead>Coordenador</TableHead>
                    <TableHead>Unidade</TableHead>
                    <TableHead>QTU</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRegistros.map((registro) => (
                    <TableRow key={registro.id}>
                      <TableCell>
                        <Badge variant="outline" className="flex items-center space-x-1">
                          <Calendar className="h-3 w-3" />
                          <span>{new Date(registro.data).toLocaleDateString('pt-BR')}</span>
                        </Badge>
                      </TableCell>
                      <TableCell className="font-medium">{registro.coordenador}</TableCell>
                      <TableCell>{registro.unidade}</TableCell>
                      <TableCell>{registro.qtu}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEdit(registro)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDelete(registro.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default RegistroManager

