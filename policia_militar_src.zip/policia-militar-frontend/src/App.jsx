import { useState, useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Users, FileText, Download, Upload, Home, Menu, X } from 'lucide-react'
import PolicialManager from './components/PolicialManager.jsx'
import RegistroManager from './components/RegistroManager.jsx'
import ExportImport from './components/ExportImport.jsx'
import './App.css'

function Navigation({ isMobileMenuOpen, setIsMobileMenuOpen }) {
  const location = useLocation()
  
  const navItems = [
    { path: '/', label: 'Início', icon: Home },
    { path: '/policiais', label: 'Policiais', icon: Users },
    { path: '/registros', label: 'Registros Diários', icon: FileText },
    { path: '/export-import', label: 'Exportar/Importar', icon: Download }
  ]

  return (
    <>
      {/* Desktop Navigation */}
      <nav className="hidden md:flex bg-blue-900 text-white p-4 shadow-lg">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Badge variant="secondary" className="bg-yellow-500 text-blue-900 font-bold">
              PM-MA
            </Badge>
            <h1 className="text-xl font-bold">Sistema de Gestão Policial</h1>
          </div>
          <div className="flex space-x-4">
            {navItems.map((item) => {
              const Icon = item.icon
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-md transition-colors ${
                    location.pathname === item.path
                      ? 'bg-blue-700 text-yellow-300'
                      : 'hover:bg-blue-800'
                  }`}
                >
                  <Icon size={18} />
                  <span>{item.label}</span>
                </Link>
              )
            })}
          </div>
        </div>
      </nav>

      {/* Mobile Navigation */}
      <nav className="md:hidden bg-blue-900 text-white p-4 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Badge variant="secondary" className="bg-yellow-500 text-blue-900 font-bold">
              PM-MA
            </Badge>
            <h1 className="text-lg font-bold">Sistema PM</h1>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="text-white hover:bg-blue-800"
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </Button>
        </div>
        
        {isMobileMenuOpen && (
          <div className="mt-4 space-y-2">
            {navItems.map((item) => {
              const Icon = item.icon
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-md transition-colors block ${
                    location.pathname === item.path
                      ? 'bg-blue-700 text-yellow-300'
                      : 'hover:bg-blue-800'
                  }`}
                >
                  <Icon size={18} />
                  <span>{item.label}</span>
                </Link>
              )
            })}
          </div>
        )}
      </nav>
    </>
  )
}

function HomePage() {
  return (
    <div className="container mx-auto p-6">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-blue-900 mb-4">
          Sistema de Gestão Policial Militar
        </h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Sistema completo para gerenciamento de policiais militares e registros diários de policiamento.
          Baseado no modelo do Batalhão de Polícia Militar de Turismo do Maranhão.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Users className="text-blue-600" />
              <span>Gestão de Policiais</span>
            </CardTitle>
            <CardDescription>
              Cadastre e gerencie informações dos policiais militares
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Link to="/policiais">
              <Button className="w-full">Acessar</Button>
            </Link>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <FileText className="text-green-600" />
              <span>Registros Diários</span>
            </CardTitle>
            <CardDescription>
              Crie e gerencie os livros diários de policiamento
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Link to="/registros">
              <Button className="w-full">Acessar</Button>
            </Link>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Download className="text-purple-600" />
              <span>Exportar/Importar</span>
            </CardTitle>
            <CardDescription>
              Exporte para PDF/DOCX ou importe dados existentes
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Link to="/export-import">
              <Button className="w-full">Acessar</Button>
            </Link>
          </CardContent>
        </Card>
      </div>

      <div className="mt-12 bg-blue-50 p-6 rounded-lg">
        <h2 className="text-2xl font-bold text-blue-900 mb-4">Funcionalidades</h2>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <h3 className="font-semibold text-blue-800 mb-2">Gestão de Policiais</h3>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• Cadastro completo de policiais militares</li>
              <li>• Busca e filtros avançados</li>
              <li>• Edição e exclusão de registros</li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-blue-800 mb-2">Registros Diários</h3>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• Formulários baseados no modelo oficial</li>
              <li>• Controle de faltas, atrasos e permutas</li>
              <li>• Gestão de equipes e viaturas</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}

function App() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navigation 
          isMobileMenuOpen={isMobileMenuOpen} 
          setIsMobileMenuOpen={setIsMobileMenuOpen} 
        />
        
        <main className="pb-8">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/policiais" element={<PolicialManager />} />
            <Route path="/registros" element={<RegistroManager />} />
            <Route path="/export-import" element={<ExportImport />} />
          </Routes>
        </main>
      </div>
    </Router>
  )
}

export default App

